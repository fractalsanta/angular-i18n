/**
*
* SearchResults
*
*/

import React from 'react';
// import styled from 'styled-components';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import NavigationChevronLeft from 'material-ui/svg-icons/navigation/chevron-left';

import {List, ListItem} from 'material-ui/List';
import Divider from 'material-ui/Divider';
import MoreVertIcon from 'material-ui/svg-icons/navigation/more-vert';
import Checkbox from 'material-ui/Checkbox';
import './styles.css';
function SearchResults({navigateToStorePages, navigateToSearch}) { // eslint-disable-line react/prefer-stateless-function
    var appBarStyle = {
        backgroundColor: "rgb(12, 162, 208)",
        position: "relative",
        top: 0,
        left: 0,
        right: 0,
        clear: "both",
        alignItems: "center",
        height:"60",
    };

    var listHeaderStyle = {
        color: "rgba(0,0,0,0.54)",
        fontWeight: "500",
        letterSpacing: ".01em",
        lineHeight: "1.2em",
        fontSize: "13px",
    };
    return (
      <div>
        <AppBar
            title="Search Results"
            iconElementLeft={<IconButton><NavigationChevronLeft style={{padding:"0"}} /></IconButton>}
            onLeftIconButtonTouchTap={navigateToSearch}
            iconStyleLeft={{opacity:".7",marginLeft:"-30px", padding:"0px"}}
            iconElementRight={<IconButton><NavigationClose /></IconButton>}
            iconStyleRight={{opacity: ".7", marginTop: "0px", marginRight:"-20px"}}
            style={appBarStyle}
            titleStyle={{fontSize:"22px"}}
            onRightIconButtonTouchTap={navigateToStorePages}
        />
        <div className="top-info-message">
            4 Results
        </div>
           <ListItem style={listHeaderStyle} >19 December, 2017</ListItem >
           <Divider />
           <ListItem
           leftIcon={<Checkbox iconStyle={{opacity:".4"}} />}
           primaryText="Store Name 1"
           secondaryText="--"
           style={{verticalAlign: "middle" }}
           insetChildren={false}
           rightIconButton={<MoreVertIcon style={{opacity:".3", top: "20"}} />}
           >
           </ListItem >
           <Divider />
           <ListItem
           leftIcon={<Checkbox iconStyle={{opacity:".4"}} />}
           primaryText="Store Name 2"
           secondaryText="--"
           style={{verticalAlign: "middle" }}
           insetChildren={false}
           rightIconButton={<MoreVertIcon style={{opacity:".3", top: "20"}} />}
           >
           </ListItem >
           <Divider />
          <ListItem style={listHeaderStyle} >18 December, 2017</ListItem >
          <Divider />
          <ListItem
              leftIcon={<Checkbox iconStyle={{opacity:".4"}} />}
              primaryText="Store Name 3"
              secondaryText="--"
              style={{verticalAlign: "middle" }}
              insetChildren={false}
              rightIconButton={<MoreVertIcon style={{opacity:".3", top: "20"}} />}
          >
          </ListItem >
          <Divider />
          <ListItem
              leftIcon={<Checkbox iconStyle={{opacity:".4"}} />}
              primaryText="Store Name 4"
              secondaryText="--"
              style={{verticalAlign: "middle" }}
              insetChildren={false}
              rightIconButton={<MoreVertIcon style={{opacity:".3", top: "20"}} />}
          >
          </ListItem >
          <Divider />
      </div>
    );

}

SearchResults.propTypes = {

};

export default SearchResults;
