// import React from 'react';
// import { shallow } from 'enzyme';

// import AboveStoreSearch from '../index';

describe('<AboveStoreSearch />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
