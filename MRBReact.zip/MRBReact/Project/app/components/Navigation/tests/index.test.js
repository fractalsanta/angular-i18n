// import React from 'react';
// import { shallow } from 'enzyme';

// import Navigation from '../index';

describe('<Navigation />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
