/**
*
* Data
*
*/

import React from 'react';
import BusyLoading from "../../components/BusyLoading";


function Data() {
  return (
    <div>
      Data
      <br />
      Data
      <br />
      Data
      <br />
      Data
      <br />
      Data
      <br />
      Data
      <br />
      Data
      <br />
      <BusyLoading />
    </div>
  );
}

Data.propTypes = {

};

export default Data;
