/**
*
* CreateFeedback
*
*/

import React from "react";
import { echoSelectFactory } from "echo-component-library/EchoSelect";
import { echoTextAreaFactory } from 'echo-component-library/EchoTextArea';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';
import RaisedButton from 'material-ui/RaisedButton';
import { Button } from "react-bootstrap";

import './styles.css';

let EchoSelect = echoSelectFactory.getClass();
let EchoTextArea =  echoTextAreaFactory.getClass();

function CreateFeedback({ pageTitles, submitFeedback, navigateToStorePages }) {

  let titleSelect = null;
  let commentsTextArea = null;
  const pageTitle = "Page Title";
  if (pageTitles.find(page => page.title === "Page Title") === undefined) {
    pageTitles.unshift({ title: "Page Title" });

  }
  const selectedOption =
    pageTitles[pageTitles.findIndex(page => page.title === pageTitle)];

  const onSubmitFeedback = () => {
    const title = titleSelect.state._selectedOptions[0].title;
    const comments = commentsTextArea.state.value;
    submitFeedback(title, comments);
    console.log(title);
    console.log(comments);
    // const feedback =
  };

    const theList = pageTitles.map(i => {
        return (
            <MenuItem className="menuItem" value={i.title} primaryText={i.title}/>
        )
    })

    var appBarStyle = {
        backgroundColor: "rgb(12, 162, 208)",
        position: "relative",
        top: 0,
        left: 0,
        right: 0,
        clear: "both",
        alignItems: "center",
        height:"60",
    };
  return (
    <div>
        <AppBar
            title="MRB Content Feedback"
            showMenuIconButton={false}
            iconElementRight={<IconButton><NavigationClose /></IconButton>}
            iconStyleRight={{opacity: ".7", marginTop: "0px", marginRight:"-20px"}}
            style={appBarStyle}
            onRightIconButtonTouchTap={navigateToStorePages}
        />

        <div className="topContainerFeedback">
            <div className="layout-align-center-center layout-column">
                <div className="infoFeedback"><b>Do you have suggestions on how to improve the book’s content?</b>
                    <p>Submit them here, and your content manager will review for the next edition.</p>
                </div>
            </div>
            <DropDownMenu children={theList} value={pageTitle} style={{width:"100%", padding: "0", border:"1px solid rgb(224, 224, 224)"}} menuItemStyle={{hover:"background-color"}} selectedMenuItemStyle={{color: "rgba(33,33,33,0.87)"}} iconStyle={{right: "-6px"}} anchorOrigin={{horizontal: 'left', vertical: 'bottom'}} underlineStyle={{marginLeft: "0", border: "0"}} labelStyle={{lineHeight: "47px", height: "46px", padding: "0px 0px 0px 8px", color: "rgba(0,0,0,0.38)"}} autoWidth={false}>

            </DropDownMenu>
        </div>

        {/*<EchoSelect
        selectorLabel="simple"
        options={pageTitles}
        selectedOptions={[selectedOption]}
        showCategories={false}
        displayBinding="title"
        valueBinding="title"
        ref={select => {
          titleSelect = select;
        }}
      />*/}
        <div className="bottomContainerFeedback">
            <div className="layout-align-center-center layout-column">

            </div>
            <EchoTextArea
                rows={7}
                label="Comments"
                className="echoTextAreaDiv"
                ref={textArea => {
                    commentsTextArea = textArea;
                }}
            />
        </div>

        {/*<Button bsStyle="primary" onClick={onSubmitFeedback}>
        Submit feedback
      </Button>*/}
        <div className="bottomContainerFeedback">

        <RaisedButton label="Submit feedback" onClick={onSubmitFeedback} buttonStyle={{height:"56px"}} fullWidth={true} labelStyle={{color: "#fff", fontWeight: 600, textTransform: "none"}} backgroundColor={"rgb(3,155,229)"} />
        </div>
     </div>
  );
}

CreateFeedback.propTypes = {};

export default CreateFeedback;
