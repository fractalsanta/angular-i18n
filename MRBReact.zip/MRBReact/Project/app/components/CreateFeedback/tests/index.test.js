// import React from 'react';
// import { shallow } from 'enzyme';

// import CreateFeedback from '../index';

describe('<CreateFeedback />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
