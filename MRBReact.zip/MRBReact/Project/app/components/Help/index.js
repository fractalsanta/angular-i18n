/**
*
* Help
*
*/

import React from 'react';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import NavigationClose from 'material-ui/svg-icons/navigation/close';

import './styles.css';

function Help({navigateToStorePages}) {
    var appBarStyle = {
        backgroundColor: "rgb(12, 162, 208)",
        position: "relative",
        top: 0,
        left: 0,
        right: 0,
        clear: "both",
        alignItems: "center",
        height:"60",
    };

  return (
    <div className="wrapperFlex">
      <AppBar
          title="Help"
          showMenuIconButton={false}
          iconElementRight={<IconButton><NavigationClose /></IconButton>}
          iconStyleRight={{opacity: ".7", marginTop: "0px", marginRight:"-20px"}}
          style={appBarStyle}
          onRightIconButtonTouchTap={navigateToStorePages}
      />
        <div className="topContainer">
            <div layout="column" layout-align="center center" className="layout-align-center-center layout-column">
                <div className="icon"><img src={require(`../../assets/images/help-icon.png`)} height="140" /></div>
                <div className="info"><b>Having trouble with the app?</b>
                    <p>We can help! Contact the Red Book Keep support team via phone or email.</p>
                </div>
            </div>
        </div>
        <div className="bottomContainer layout-align-center-center layout-column flex" flex layout-align="center center">
            <div layout="column" className="layout-column">
                <div className="info">
                    <h1>Phone:</h1>
                    <p><a href="tel:8005269635">877-720-8578</a>
                    </p>
                </div>
                <div className="info">
                    <h1>Email:</h1>
                    <p><a href="mailto:customercare@hotschedules.com">customercare@hotschedules.com</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
  );
}

Help.propTypes = {

};

export default Help;
