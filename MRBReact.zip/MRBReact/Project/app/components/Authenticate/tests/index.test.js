// import React from 'react';
// import { shallow } from 'enzyme';

// import Authenticate from '../index';

describe('<Authenticate />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
