/**
*
* Authenticate
*
*/

import React from "react";
import BusyLoading from "../../components/BusyLoading";
// import styled from 'styled-components';

function Authenticate() {
  return (
    <div>
      Authenticate
      <br />
      Authenticate
      <br />
      Authenticate
      <br />
      Authenticate
      <br />
      Authenticate
      <br />
      Authenticate
      <br />
      Authenticate
      <br />
      <BusyLoading />
    </div>
  );
}

Authenticate.propTypes = {};

export default Authenticate;
