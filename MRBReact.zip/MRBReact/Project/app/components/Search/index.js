/**
*
* Search
*
*/

import React from 'react';
// import styled from 'styled-components';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import DropDownMenu from 'material-ui/DropDownMenu';
import { echoDatePickerFactory } from 'echo-component-library/EchoDatePicker';
import moment from 'moment'
import {RadioButton, RadioButtonGroup} from 'material-ui/RadioButton';
import MenuItem from 'material-ui/MenuItem';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import ToggleRadioButtonUnchecked from 'material-ui/svg-icons/toggle/radio-button-unchecked'
import UnCheckedIcon from 'material-ui/svg-icons/toggle/check-box-outline-blank';
import CheckedIcon from 'material-ui/svg-icons/toggle/check-box'

import './styles.css';

let EchoDatePicker =  echoDatePickerFactory.getClass();

function Search({navigateToStorePages, doSearch}) {
    const toDate = moment().format('MM/DD/YYYY');



    const theList = () => (
        <DropDownMenu  className="period" value="Last 3 Months" style={{width:"100%", padding: "0", border:"1px solid rgb(224, 224, 224)", zIndex:"998", fontWeight: 400}}  menuItemStyle={{hover:"background-color"}} selectedMenuItemStyle={{color: "rgba(33,33,33,0.87)"}} iconStyle={{right: "-6px", top:"0"}} anchorOrigin={{horizontal: 'left', vertical: 'bottom'}} underlineStyle={{marginLeft: "0", border: "0"}} labelStyle={{lineHeight: "47px", height: "46px", padding: "0px 0px 0px 8px", color: "rgba(0,0,0,0.38)"}} autoWidth={false}>
            <MenuItem value="Last 3 Months" primaryText="Last 3 Months"/>
            <MenuItem value="This Month" primaryText="This Month"/>
            <MenuItem value="This Week" primaryText="This Week"/>
        </DropDownMenu>
    )
    const datePicker = () => (
        <EchoDatePicker
            value={toDate}
            className="datepicker"
        />
    )
    var appBarStyle = {
        backgroundColor: "rgb(12, 162, 208)",
        position: "relative",
        top: 0,
        left: 0,
        right: 0,
        clear: "both",
        alignItems: "center",
        height:"60",
    };
  return (
    <div className="wrapperFlex">
        <AppBar
            title="Search Store"
            titleStyle={{fontSize:"22px"}}
            showMenuIconButton={false}
            iconElementRight={<IconButton><NavigationClose /></IconButton>}
            iconStyleRight={{opacity: ".7", marginTop: "0px", marginRight:"-20px"}}
            style={appBarStyle}
            onRightIconButtonTouchTap={navigateToStorePages}
        />
        <div className="topContainer">
            <div layout="column" layout-align="center center" className="layout-align-center-center layout-column">
                <div className="info">
                    <p>Start by selecting either a time period or a specific page date.</p>
                </div>
            </div>
        </div>
        <div className="topContainer nopadding">
            <div className="searchRow">

                    <RadioButtonGroup  name="shipSpeed"  defaultSelected="period" style={{width:"100%"}}>
                        <RadioButton onCheck={(e)=> this.labelStyle="#CCCCCC"} value="period" uncheckedIcon={<ToggleRadioButtonUnchecked style={{fill: "#D9DBDC"}} />} iconStyle={{top:"5px"}} label={theList()} labelStyle={{width: "100%"}}  />
                        <RadioButton onCheck={(e)=> this.labelStyle=""} label={datePicker()} uncheckedIcon={<ToggleRadioButtonUnchecked style={{fill: "#D9DBDC"}} />} iconStyle={{top:"5px"}} labelStyle={{width: "100%"}}   />
                    </RadioButtonGroup>

            </div>

        </div>
        <div className="topContainer" style={{paddingTop:"0"}}>
            <div layout="column" className="layout-align-center-center layout-column">
                <div className="info">
                    <p>Next, add modifiers. (Optional)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
                </div>
            </div>
            <DropDownMenu  className="modifiers"  value="Page Title" style={{width:"100%", padding: "0", border:"1px solid rgb(224, 224, 224)", zIndex:"999"}}  menuItemStyle={{hover:"background-color"}} selectedMenuItemStyle={{color: "rgba(33,33,33,0.87)"}} iconStyle={{right: "-6px", top:"0"}} anchorOrigin={{horizontal: 'left', vertical: 'bottom'}} underlineStyle={{marginLeft: "0", border: "0"}} labelStyle={{lineHeight: "47px", height: "46px", padding: "0px 0px 0px 8px", color: "rgba(0,0,0,0.38)"}} autoWidth={false}>
                <MenuItem value="Page Title" primaryText="Page Title"/>
                <MenuItem value="Daily Page 1 Shift Totals" primaryText="Daily Page 1 Shift Totals"/>
                <MenuItem value="Daily Page 2 Incoming Messages" primaryText="Daily Page 2 Incoming Messages"/>
                <MenuItem value="Weekly Meeting Notes" primaryText="Weekly Meeting Notes"/>
                <MenuItem value="Weekly Results" primaryText="Weekly Results"/>
                <MenuItem value="Weekly Summary" primaryText="Weekly Summary"/>
                <MenuItem value="Daily Page - Manager's Summary" primaryText="Daily Page - Manager's Summary"/>
                <MenuItem value="Line Check" primaryText="Line Check"/>
            </DropDownMenu>

            <div className="searchRow">
                <div className="rowleft">
                    <Checkbox uncheckedIcon={<UnCheckedIcon style={{fill: "#D9DBDC"}} />}
                              checkedIcon={<CheckedIcon style={{fill: "rgb(0, 188, 212)"}} />}
                    />
                </div>
                <div className="rowright">
                    Has Comments
                </div>
            </div>
            <div className="searchRow">
                <div className="rowleft">
                    <Checkbox uncheckedIcon={<UnCheckedIcon style={{fill: "#D9DBDC"}} />}
                              checkedIcon={<CheckedIcon style={{fill: "rgb(0, 188, 212)"}} />}
                    />
                </div>
                <div className="rowright">
                    Incomplete pages only
                </div>
            </div>
        </div>
        <div className="bottomContainerSearch">
            <RaisedButton label="Search" buttonStyle={{height:"56px"}} fullWidth={true} onClick={doSearch} labelStyle={{color: "#fff", fontWeight: 600, textTransform: "none"}} backgroundColor={"rgb(3,155,229)"} />
        </div>
    </div>
  );
}

Search.propTypes = {

};

export default Search;
