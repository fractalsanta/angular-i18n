// import React from 'react';
// import { shallow } from 'enzyme';

// import FeedbackGroups from '../index';

describe('<FeedbackGroups />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
