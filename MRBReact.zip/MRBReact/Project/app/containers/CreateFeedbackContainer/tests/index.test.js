// import React from 'react';
// import { shallow } from 'enzyme';

// import { CreateFeedbackContainer } from '../index';

describe('<CreateFeedbackContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
