// import { fromJS } from 'immutable';
// import { makeSelectCreateFeedbackContainerDomain } from '../selectors';

// const selector = makeSelectCreateFeedbackContainerDomain();

describe('makeSelectCreateFeedbackContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
