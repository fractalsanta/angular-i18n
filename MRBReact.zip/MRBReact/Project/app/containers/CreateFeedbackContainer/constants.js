/*
 *
 * CreateFeedbackContainer constants
 *
 */

export const SUBMIT_FEEDBACK = 'app/CreateFeedbackContainer/SUBMIT_FEEDBACK';
