// import { fromJS } from 'immutable';
// import { makeSelectAuthenticateContainerDomain } from '../selectors';

// const selector = makeSelectAuthenticateContainerDomain();

describe('makeSelectAuthenticateContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
