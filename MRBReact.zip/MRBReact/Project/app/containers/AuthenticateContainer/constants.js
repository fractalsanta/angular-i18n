/*
 *
 * AuthenticateContainer constants
 *
 */

export const AUTHENTICATE = "app/AuthenticateContainer/AUTHENTICATE";
export const AUTHENTICATE_SUCCESS =
  "app/AuthenticateContainer/AUTHENTICATE_SUCCESS";
export const SET_CURRENT_STORE_ID = "app/AuthenticateContainer/SET_CURRENT_STORE_ID";
