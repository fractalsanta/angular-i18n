// import { fromJS } from 'immutable';
// import { makeSelectDataContainerDomain } from '../selectors';

// const selector = makeSelectDataContainerDomain();

describe('makeSelectDataContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
