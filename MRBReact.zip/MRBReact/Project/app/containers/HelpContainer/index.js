/*
 *
 * HelpContainer
 *
 */

import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import Help from "../../components/Help";
import { push } from "react-router-redux";

export class HelpContainer extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <div>
        <Help {...this.props} />
      </div>
    );
  }
}

HelpContainer.propTypes = {
  dispatch: PropTypes.func.isRequired,
};


function mapDispatchToProps(dispatch) {
  return {
     navigateToStorePages: () => dispatch(push('/storepages')),
  };
}

export default connect(null, mapDispatchToProps)(HelpContainer);
