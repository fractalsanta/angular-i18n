// import { fromJS } from 'immutable';
// import { makeSelectNavigationContainerDomain } from '../selectors';

// const selector = makeSelectNavigationContainerDomain();

describe('makeSelectNavigationContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
