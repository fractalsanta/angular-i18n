/*
 *
 * NavigationContainer constants
 *
 */

export const TOGGLE_DRAWER = 'app/NavigationContainer/TOGGLE_DRAWER';
export const TOGGLE_SELECT_STORE = 'app/NavigationContainer/TOGGLE_SELECT_STORE';
export const NAVIGATE_TO_STORES = 'app/NavigationContainer/NAVIGATE_TO_STORES';