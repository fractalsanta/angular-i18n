/*
 *
 * StoreProgressContainer constants
 *
 */
export const UPDATE_SELECTED_DATE = "update_selected_date";
export const SELECT_STORE_FOR_DATE = "select_store_for_date";
export const DISPLAY_SELECTED_DOCUMENTS = "display_selected_documents";
export const LOAD_ABOVE_STORE_SEARCH = "load_above_store_search";
export const TOGGLE_DRAWER = 'app/NavigationContainer/TOGGLE_DRAWER';