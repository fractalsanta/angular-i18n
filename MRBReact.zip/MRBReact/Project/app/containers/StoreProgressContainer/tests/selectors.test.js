// import { fromJS } from 'immutable';
// import { makeSelectStoreProgressContainerDomain } from '../selectors';

// const selector = makeSelectStoreProgressContainerDomain();

describe('makeSelectStoreProgressContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
