// import React from 'react';
// import { shallow } from 'enzyme';

// import { StoreProgressContainer } from '../index';

describe('<StoreProgressContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
