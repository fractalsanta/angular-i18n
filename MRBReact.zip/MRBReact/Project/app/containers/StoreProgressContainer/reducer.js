/*
 *
 * StoreProgressContainer reducer
 *
 */

import { fromJS } from "immutable";
import moment from "moment";
import {
  FETCH_STORES_WITH_DETAILS_SUCCESS,
  UPDATE_SELECTED_DATE,
  SET_SELECTED_DOCUMENTS,
  STORE_PAGE_TITLES,
  TOGGLE_DRAWER
} from "./constants";

const initialState = fromJS({
  selectedDate: "2017-10-10",
  storesWithDetails: [],
  isDrawerOpen: false,
});

function storeProgressContainerReducer(state = initialState, action) {
  switch (action.type) {
    case UPDATE_SELECTED_DATE:
      return state.set(
        "selectedDate",
        moment(action.date).format("YYYY-MM-DD")
      );
    case TOGGLE_DRAWER:
      return state.set("isDrawerOpen", !state.get("isDrawerOpen"));
    default:
      return state;
  }
}

export default storeProgressContainerReducer;
