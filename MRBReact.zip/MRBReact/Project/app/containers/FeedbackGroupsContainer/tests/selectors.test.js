// import { fromJS } from 'immutable';
// import { makeSelectFeedbackGroupsContainerDomain } from '../selectors';

// const selector = makeSelectFeedbackGroupsContainerDomain();

describe('makeSelectFeedbackGroupsContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
