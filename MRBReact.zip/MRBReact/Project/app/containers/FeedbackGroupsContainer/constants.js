/*
 *
 * FeedbackGroupsContainer constants
 *
 */

export const SELECT_FEEDBACK_BY_TITLE = 'app/FeedbackGroupsContainer/SELECT_FEEDBACK_BY_TITLE';
export const SET_SELECTED_FEEDBACK_TITLE = 'app/FeedbackGroupsContainer/SET_SELECTED_FEEDBACK_TITLE';

