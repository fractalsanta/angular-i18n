/*
 *
 * SearchResultsContainer
 *
 */

import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import makeSelectSearchResultsContainer from './selectors';
import SearchResults from '../../components/SearchResults'
import { push } from "react-router-redux";
export class SearchResultsContainer extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <div>
        <SearchResults {...this.props} />
      </div>
    );
  }
}

SearchResultsContainer.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  SearchResultsContainer: makeSelectSearchResultsContainer(),
});

function mapDispatchToProps(dispatch) {
  return {
      navigateToStorePages: () => dispatch(push('/storepages')),
      navigateToSearch: () => dispatch(push('/search')),
  };
}

export default connect(null, mapDispatchToProps)(SearchResultsContainer);
