import { createSelector } from 'reselect';

/**
 * Direct selector to the searchResultsContainer state domain
 */
const selectSearchResultsContainerDomain = () => (state) => state.get('searchResultsContainer');

/**
 * Other specific selectors
 */


/**
 * Default selector used by SearchResultsContainer
 */

const makeSelectSearchResultsContainer = () => createSelector(
  selectSearchResultsContainerDomain(),
  (substate) => substate.toJS()
);

export default makeSelectSearchResultsContainer;
export {
  selectSearchResultsContainerDomain,
};
