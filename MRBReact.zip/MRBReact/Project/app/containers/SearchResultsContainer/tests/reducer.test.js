
import { fromJS } from 'immutable';
import searchResultsContainerReducer from '../reducer';

describe('searchResultsContainerReducer', () => {
  it('returns the initial state', () => {
    expect(searchResultsContainerReducer(undefined, {})).toEqual(fromJS({}));
  });
});
