// import { fromJS } from 'immutable';
// import { makeSelectSearchResultsContainerDomain } from '../selectors';

// const selector = makeSelectSearchResultsContainerDomain();

describe('makeSelectSearchResultsContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
