/*
 *
 * SearchResultsContainer constants
 *
 */

export const DEFAULT_ACTION = 'app/SearchResultsContainer/DEFAULT_ACTION';
