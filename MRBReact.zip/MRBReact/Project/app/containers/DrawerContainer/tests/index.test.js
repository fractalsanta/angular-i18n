// import React from 'react';
// import { shallow } from 'enzyme';

// import { DrawerContainer } from '../index';

describe('<DrawerContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
