// import { fromJS } from 'immutable';
// import { makeSelectDrawerContainerDomain } from '../selectors';

// const selector = makeSelectDrawerContainerDomain();

describe('makeSelectDrawerContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
