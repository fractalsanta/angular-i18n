/*
 *
 * DrawerContainer constants
 *
 */

export const TOGGLE_DRAWER = 'app/DrawerContainer/TOGGLE_DRAWER';
