/*
 *
 * DrawerContainer actions
 *
 */

import {
  TOGGLE_DRAWER,
} from './constants';

export function toggleDrawer() {
  return {
    type: TOGGLE_DRAWER,
  };
}
