// import { fromJS } from 'immutable';
// import { makeSelectSelectStoreContainerDomain } from '../selectors';

// const selector = makeSelectSelectStoreContainerDomain();

describe('makeSelectSelectStoreContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
