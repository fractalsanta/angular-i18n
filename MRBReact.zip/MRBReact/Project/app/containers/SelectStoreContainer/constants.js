/*
 *
 * SelectStoreContainer constants
 *
 */
export const TOGGLE_SELECT = 'app/NavigationContainer/TOGGLE_SELECT';
export const NAVIGATE_TO_STORES = 'app/NavigationContainer/NAVIGATE_TO_STORES';
export const NAVIGATE_BACK = 'app/NavigationContainer/NAVIGATE_BACK';