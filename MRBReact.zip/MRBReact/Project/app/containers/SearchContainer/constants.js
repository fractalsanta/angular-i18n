/*
 *
 * SearchContainer constants
 *
 */

export const DEFAULT_ACTION = 'app/SearchContainer/DEFAULT_ACTION';
export const DATE_SELECTED = 'app/SearchContainer/DATE_SELECTED';