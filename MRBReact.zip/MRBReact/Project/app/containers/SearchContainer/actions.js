/*
 *
 * SearchContainer actions
 *
 */

import {
  DATE_SELECTED,
} from './constants';

export function handleDateSelect() {
    return {
        type: DATE_SELECTED,
    };
}
