// import { fromJS } from 'immutable';
// import { makeSelectSearchContainerDomain } from '../selectors';

// const selector = makeSelectSearchContainerDomain();

describe('makeSelectSearchContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
