/*
 *
 * SearchContainer
 *
 */

import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import makeSelectSearchContainer from './selectors';
import Search from '../../components/Search'
import { push } from "react-router-redux";
export class SearchContainer extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <div>
        <Search {...this.props} />
      </div>
    );
  }
}

SearchContainer.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  SearchContainer: makeSelectSearchContainer(),
});

function mapDispatchToProps(dispatch) {
  return {
      navigateToStorePages: () => dispatch(push('/storepages')),
      doSearch: () => dispatch(push('/searchresults')),
  };
}

export default connect(null, mapDispatchToProps)(SearchContainer);
