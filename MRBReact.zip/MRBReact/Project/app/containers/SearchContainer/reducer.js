/*
 *
 * SearchContainer reducer
 *
 */

import { fromJS } from 'immutable';
import {
  DEFAULT_ACTION,
  DATE_SELECTED,
} from './constants';

const initialState = fromJS({
    selectedDate: true,
});

function searchContainerReducer(state = initialState, action) {
  switch (action.type) {
    case DEFAULT_ACTION:
      return state;
    case DATE_SELECTED:
      return state.set("selectedDate", !state.get("selectedDate"));
    default:
      return state;
  }
}

export default searchContainerReducer;
