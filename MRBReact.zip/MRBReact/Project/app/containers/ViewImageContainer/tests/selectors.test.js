// import { fromJS } from 'immutable';
// import { makeSelectViewImageContainerDomain } from '../selectors';

// const selector = makeSelectViewImageContainerDomain();

describe('makeSelectViewImageContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
