/*
 *
 * ViewImageContainer constants
 *
 */

export const REQUEST_IMAGE_SUCCEEDED = 'app/ViewImageContainer/REQUEST_IMAGE_SUCCEEDED';
export const REQUEST_IMAGE_FAILED = 'app/ViewImageContainer/REQUEST_IMAGE_FAILED';
export const REQUEST_IMAGE = 'app/ViewImageContainer/REQUEST_IMAGE';
export const CLEAR_IMAGE = 'app/ViewImageContainer/CLEAR_IMAGE';
