/*
 *
 * AboveStoreSearchContainer constants
 *
 */

export const TOGGLE_CRITERIA_COMPLETED = 'app/AboveStoreSearchContainer/TOGGLE_CRITERIA_COMPLETED';
export const CHANGE_CRITERIA_PAGE_TITLE = 'app/AboveStoreSearchContainer/CHANGE_CRITERIA_PAGE_TITLE';
export const DISPLAY_SEARCH_DOCUMENTS = 'app/AboveStoreSearchContainer/DISPLAY_SEARCH_DOCUMENTS';
