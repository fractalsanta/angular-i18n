// import { fromJS } from 'immutable';
// import { makeSelectAboveStoreSearchContainerDomain } from '../selectors';

// const selector = makeSelectAboveStoreSearchContainerDomain();

describe('makeSelectAboveStoreSearchContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
