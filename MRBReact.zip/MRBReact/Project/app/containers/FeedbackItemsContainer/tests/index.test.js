// import React from 'react';
// import { shallow } from 'enzyme';

// import { FeedbackItemsContainer } from '../index';

describe('<FeedbackItemsContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
