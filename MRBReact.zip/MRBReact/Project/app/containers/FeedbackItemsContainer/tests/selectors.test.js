// import { fromJS } from 'immutable';
// import { makeSelectFeedbackItemsContainerDomain } from '../selectors';

// const selector = makeSelectFeedbackItemsContainerDomain();

describe('makeSelectFeedbackItemsContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
