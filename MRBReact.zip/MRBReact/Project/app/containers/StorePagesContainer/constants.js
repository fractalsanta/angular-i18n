/*
 *
 * StorePagesContainer constants
 *
 */

export const VIEW_IMAGE = 'app/StorePagesContainer/VIEW_IMAGE';
export const TOGGLE_DRAWER = 'app/NavigationContainer/TOGGLE_DRAWER';
export const UPLOAD_IMAGE = 'app/StorePagesContainer/UPLOAD_IMAGE';

