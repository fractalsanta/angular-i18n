// import React from 'react';
// import { shallow } from 'enzyme';

// import { StorePagesContainer } from '../index';

describe('<StorePagesContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
