// import { fromJS } from 'immutable';
// import { makeSelectStorePagesContainerDomain } from '../selectors';

// const selector = makeSelectStorePagesContainerDomain();

describe('makeSelectStorePagesContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
