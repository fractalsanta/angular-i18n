import { FilterPopOverPage } from './filter-pop-over';
import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

@NgModule({
  declarations: [FilterPopOverPage],
  imports: [IonicPageModule.forChild(FilterPopOverPage)],
  entryComponents: [FilterPopOverPage]
})
export class FilterPopOverModule {}
