// Highlight the current page in the menu
$(document).ready(function () {
    var pageUrl = window.location.pathname;
    var selectedPage = $('a[href*="' + pageUrl.substring(7) + '"]');

    selectedPage.addClass('selected');
});